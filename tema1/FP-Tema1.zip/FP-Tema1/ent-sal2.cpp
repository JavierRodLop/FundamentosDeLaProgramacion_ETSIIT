#include <iostream>
using namespace std;

int main()
{
    //SALIDAS
    cout << "Primera linea";
    cout << " -> A continuacion";
    cout << "\nSiguiente linea"; // \n = salto de l�nea
    cout << "\n\tPrimera tabulacion"; // \t = tabulador
    cout << "\n\t\tSegunda tabulacion"; // \t = tabulador
}

