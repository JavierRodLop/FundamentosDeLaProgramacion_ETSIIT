#include <iostream>
using namespace std;int main(){double d1,d2,r;cout<<"Introducir dato: ";cin>>d1;   
cout<<"Introducir dato: ";cin >> d2;if (d1!= 5)cout<<"Resultado:" << -d2/d1;}
