      // Programa que lee dos n�meros enteros por teclado
      // y muestra por pantalla su suma

      #include <iostream>
      using namespace std;

      int main()
      {
           int variable1;
           int variable2;
           int suma;

           cout << "Introducir primer dato: ";
           cin >> variable1;

           cout << "Introducir segundo dato: ";
           cin >> variable2;

           suma = variable1 + variable2;

           cout << "La suma es: " << suma << endl;
     }

