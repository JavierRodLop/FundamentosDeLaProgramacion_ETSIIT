      // Primer programa en C++
      // Escribe en pantalla un mensaje

      #include <iostream>
      using namespace std;

      int main()
      {
        cout << "Bienvenido a C++" << endl;
      }

