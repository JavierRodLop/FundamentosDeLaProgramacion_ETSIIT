      #include <iostream>
      using namespace std;

      int main()
      {
          int dato1 = 30, dato2, suma;

          suma = dato1 + dato2;

          cout << "La suma: " << suma << endl;
      }


